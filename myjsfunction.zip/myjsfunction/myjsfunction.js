function changeImage()
{ 
   var image = document.getElementById('myImage');
   if
     (image.src.match("cashlogo.jpg"))
      {
	image.src="bitcoin.jpg";
      }
    else{
      image.src="cashlogo.jpg";
    }
	
      
     
}
